package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.exception.NoSuchAssignmentException;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represent Rendering Event For Adding and Editing An Assignment
 * @author hgrahul
 *
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.EDIT_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class EditAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Considering We Are Adding A New Assignment, Assignment Will Empty In That Case
		Assignment assignment = null;
		
		// If Purpose Is For Editing We Will Also Have AssignmentId
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId", 0);
		
		// If AssignmentId Is Created Then Zero, Purpose Is For Editing An Assignment
		if(assignmentId > 0) {
			try {
				assignment = assignmentService.getAssignment(assignmentId);
			}
			catch (NoSuchAssignmentException nsae) {
				nsae.printStackTrace();
			}
			catch (PortalException poe) {
				poe.printStackTrace();
			}
		}
		
		// Setting Up A Back Button For Single Assignment View
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
					
		String redirect = renderRequest.getParameter("redirect");
					
		portletDisplay.setShowBackIcon(true);
		portletDisplay.setURLBack(redirect);
		
		// Updating Assignment Details For Adding Or Editing Purpose
		renderRequest.setAttribute("assignment", assignment);
		renderRequest.setAttribute("assignmentClass", Assignment.class);
		
		// Returning To Appropraite Views
		return "/assignment/edit_assignment.jsp";
	}
	
	@Reference
	private AssignmentService assignmentService;
}
