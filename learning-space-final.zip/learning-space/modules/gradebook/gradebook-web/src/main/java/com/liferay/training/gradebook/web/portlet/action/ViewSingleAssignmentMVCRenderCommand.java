package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;

import java.text.DateFormat;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represent Rendering Event For Viewing An Single Or Individual Assignment
 * 
 * @author hgrahul
 *
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENT
	},
	service = MVCRenderCommand.class
)
public class ViewSingleAssignmentMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Need To The Get Assignment Id For Which We Need To Show The Assignment Details
		long assignmentId = ParamUtil.getLong(renderRequest, "assignmentId" , 0);
		try {
			// Now Call For Assignment Services To Get The Assignment Details
			Assignment assignment = assignmentService.getAssignment(assignmentId);
			
			// Formating Information Which Later Will Be Display On Appropriate Views
			DateFormat simpleDateFormat = DateFormatFactoryUtil.getSimpleDateFormat("EEEEE, MMMMM dd, yyyy", renderRequest.getLocale());
			
			renderRequest.setAttribute("assignment", assignment);
			renderRequest.setAttribute("dueDate", simpleDateFormat.format(assignment.getDueDate()));
			renderRequest.setAttribute("createDate", simpleDateFormat.format(assignment.getCreateDate()));
			
			// Setting Up A Back Button For Single Assignment View
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();
			
			String redirect = renderRequest.getParameter("redirect");
			
			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			// Finally Returning Appropraite View JSP
			return "/assignment/view_assignment.jsp";
		}
		catch (PortalException poe) {
			throw new PortletException();
		}
	}
	
	@Reference
	private AssignmentService assignmentService;
}
