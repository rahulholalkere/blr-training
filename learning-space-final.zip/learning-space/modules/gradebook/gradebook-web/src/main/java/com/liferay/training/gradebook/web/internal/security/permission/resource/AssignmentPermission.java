package com.liferay.training.gradebook.web.internal.security.permission.resource;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.training.gradebook.model.Assignment;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author hgrahul
 * This Class Represents Class For Checking Assignment Entity Permissions
 */
@Component(immediate = true, service = AssignmentPermission.class)
public class AssignmentPermission {
	public static boolean contains(PermissionChecker permissionChecker, long assignmentId, String actionKeys) throws PortalException{
		return assignmentModelResourcePermission.contains(permissionChecker, assignmentId, actionKeys);
	}
	
	public static boolean contains(PermissionChecker permissionChecker, Assignment assignment, String actionKeys) throws PortalException{
		return assignmentModelResourcePermission.contains(permissionChecker, assignment, actionKeys);
	}
	
	@Reference(target = "(model.class.name=com.liferay.training.gradebook.model.Assignment)", unbind = "-")
	protected void setAssignmentModelResourcePermission(ModelResourcePermission<Assignment> assignmentModelResourcePermission) {
		this.assignmentModelResourcePermission = assignmentModelResourcePermission;
	}
	
	private static ModelResourcePermission<Assignment> assignmentModelResourcePermission;
}
