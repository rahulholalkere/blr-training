package com.liferay.training.gradebook.web.portlet.action;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.portlet.LiferayPortlet;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentService;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;
import com.liferay.training.gradebook.web.display.context.AssignmentsManagementToolbarDisplayContext;
import com.liferay.training.gradebook.web.internal.security.permission.resource.AssignmentPermission;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represent Rendering Event Before Showing All The Assignment List In Appropriate View JSP
 * @author hgrahul
 *
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + GradebookPortletKeys.PORTLET_NAME,
		"mvc.command.name=/",
		"mvc.command.name=" + MVCCommandNames.VIEW_ASSIGNMENTS,
	},
	service = MVCRenderCommand.class
)
public class ViewAssignmentsMVCRenderCommand implements MVCRenderCommand{
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// Adding Management Toolbar For Assignment Related Works (Filtering, Ordering & Search with Addition Icon)
		addManagementToolbarAttributes(renderRequest, renderResponse);
		
		// Adding All Assignment Information To The Request For Further Rendering View In Appropriate JSP
		addAssignmentListAttributes(renderRequest);
		
		// Adding Assignment Permission Details To The Request
		renderRequest.setAttribute("assignmentPermission", assignmentPermission);
		
		// Redirect To Appropraite JSP
		return "/view.jsp";
	}
	
	private void addManagementToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
		LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
		HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);
		
		// Need To Instanciate Assignment Managment Toolbar Display Context
		AssignmentsManagementToolbarDisplayContext assignmentsManagementToolbarDisplayContext = new AssignmentsManagementToolbarDisplayContext(liferayPortletRequest, liferayPortletResponse, httpServletRequest);
		
		// Setting Up The AssignmentManagementToolbarDisplayContext To The Request
		renderRequest.setAttribute("assignmentsManagementToolbarDisplayContext", assignmentsManagementToolbarDisplayContext);
	}
	
	/**
	 * This behavior represent retrieving assignment information and adding to request for further view prespective.
	 * @param renderRequest
	 */
	private void addAssignmentListAttributes(RenderRequest renderRequest) {
		// Resolve Start and End Of Search Container
		int currentPage = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_CUR);
		int delta = ParamUtil.getInteger(renderRequest, SearchContainer.DEFAULT_DELTA_PARAM, SearchContainer.DEFAULT_DELTA);
		
		// Calculate The Start and End Values From Current and Delta Pages
		int start = ((currentPage > 0) ? (currentPage - 1) : 0) * delta;
		int end = start + delta;
		
		// Getting Sorting Details (Type and Column)
		String orderByCol = ParamUtil.getString(renderRequest, "orderByCol", "title");
		String orderByType = ParamUtil.getString(renderRequest, "orderByType", "asc");
		
		// Getting The Search Keywords From Appropriate Views
		String keywords = ParamUtil.getString(renderRequest, "keywords");
		
		// We Will Also Need To OrderByComparator For Retrival Purpose
		OrderByComparator<Assignment> orderByComparator = OrderByComparatorFactoryUtil.create("Assignment", orderByCol, ("asc").equals(orderByType));
		
		// Need The Website Id or GroupId For Further Retrival Needs
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();

		// Finally Going For A Retrival Process (List Of Assignment & Count)
		List<Assignment> assignments = assignmentService.getAssignmentsByKeywords(groupId, keywords, start, end, orderByComparator);
		long assignmentCount = assignmentService.getAssignmentsCountByKeywords(groupId, keywords);
		
		// Setting The AssignmentList and AssignmentCount To The Request
		renderRequest.setAttribute("assignments", assignments);
		renderRequest.setAttribute("assignmentCount", assignmentCount);
	}
	
	@Reference
	private AssignmentService assignmentService;
	
	@Reference
	private AssignmentPermission assignmentPermission;
	
	@Reference
	private Portal portal;
}
