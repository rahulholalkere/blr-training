package com.liferay.training.gradebook.web.display.context;

import com.liferay.frontend.taglib.clay.servlet.taglib.display.context.BaseManagementToolbarDisplayContext;
import com.liferay.frontend.taglib.clay.servlet.taglib.util.CreationMenu;
import com.liferay.frontend.taglib.clay.servlet.taglib.util.DropdownItem;
import com.liferay.frontend.taglib.clay.servlet.taglib.util.DropdownItemList;
import com.liferay.frontend.taglib.clay.servlet.taglib.util.ViewTypeItem;
import com.liferay.frontend.taglib.clay.servlet.taglib.util.ViewTypeItemList;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.language.LanguageUtil;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.PortalPreferences;
import com.liferay.portal.kernel.portlet.PortletPreferencesFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.security.permission.ActionKeys;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.gradebook.web.constants.GradebookPortletKeys;
import com.liferay.training.gradebook.web.constants.MVCCommandNames;
import com.liferay.training.gradebook.web.internal.security.permission.resource.AssignmentTopLevelPermission;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.servlet.http.HttpServletRequest;

/**
 * @author hgrahul
 * This Class Passes Contextual Information About The Assignment To The User Interface For Clay Management Toolbar
 * 1. Adding A New Assignment
 * 2. Search Operation
 * 3. Ordering And Filtering
 * 4. Display Style With View Mapping
 */

public class AssignmentsManagementToolbarDisplayContext extends BaseManagementToolbarDisplayContext{
	public AssignmentsManagementToolbarDisplayContext(LiferayPortletRequest liferayPortletRequest, LiferayPortletResponse liferayPortletResponse, HttpServletRequest httpServletRequest) {
		// For Sharing Assignment Details To The Base Implementation Of Clay Management Toolbar
		super(liferayPortletRequest, liferayPortletResponse, httpServletRequest);
		
		// To Help With Assignment Management Toolbar Post Seeding Information
		portalPreferences = PortletPreferencesFactoryUtil.getPortalPreferences(liferayPortletRequest);
		themeDisplay = (ThemeDisplay) httpServletRequest.getAttribute(WebKeys.THEME_DISPLAY);
	}
	
	/**
	 * Returns The Creation Menu For The Assignment Management Toolbar
	 * (Plus Sign On The Management Toolbar)
	 */
	@Override
	public CreationMenu getCreationMenu() {
		// If User Does Not Have Permission To Add A New Assignment
		if(!AssignmentTopLevelPermission.contains(themeDisplay.getPermissionChecker(), themeDisplay.getScopeGroupId(), ActionKeys.ADD_ENTRY)) {
			return null;
		}
		// Creation Menu For Adding A New Assignment If You Have Permission
		return new CreationMenu() {
			{
				addDropdownItem(
					dropdownItem -> {
						dropdownItem.setHref(liferayPortletResponse.createRenderURL(), "mvcRenderCommandName", MVCCommandNames.EDIT_ASSIGNMENT, "redirect", currentURLObj.toString());
						dropdownItem.setLabel(LanguageUtil.get(request, "add-assignment"));
					}
				);
			}
		};
	}


	@Override
	public String getClearResultsURL() {
		return getSearchActionURL();
	}
	
	@Override
	public String getDisplayStyle() {
		// Getting The Display Style From The Management Toolbar (If Style Been Set Or Not Set)
		String displayStyle = ParamUtil.getString(request, "displayStyle");
		
		if(Validator.isNull(displayStyle)) {
			displayStyle = portalPreferences.getValue(GradebookPortletKeys.PORTLET_NAME, "assignment-display-style", "descriptive");
		}
		else {
			portalPreferences.setValue(GradebookPortletKeys.PORTLET_NAME, "assignment-display-style", displayStyle);
			
			// Need To Ensure That We Clear The Cache So That It Can Use The New Style
			request.setAttribute(WebKeys.SINGLE_PAGE_APPLICATION_CLEAR_CACHE, Boolean.TRUE);
		}
		
		return displayStyle;
	}
	
	/**
	 * Returning The Order By Column Information
	 */
	@Override
	protected String getOrderByCol() {
		return ParamUtil.getString(request, "orderByCol", "title");
	}
	
	/**
	 * Returning The Order By Type Information	
	 */
	@Override
	protected String getOrderByType() {
		return ParamUtil.getString(request, "orderByType", "asc");
	}
	
	/**
	 * Return The List Of Assignment With Search Action URL and Appropriate Views
	 */
	@Override
	public String getSearchActionURL() {
		// First I Need To Create A Generic Search URL
		PortletURL searchURL = liferayPortletResponse.createRenderURL();
		
		// Need To Setup The Parameter For The URL Created (Commands, Entries & Ordering (Columns and Type)
		searchURL.setParameter("mvcRenderCommnandName", MVCCommandNames.VIEW_ASSIGNMENTS);
		String navigation = ParamUtil.getString(request, "navigation", "entries");
		searchURL.setParameter("navigation", navigation);
		searchURL.setParameter("orderByCol", getOrderByCol());
		searchURL.setParameter("orderByType", getOrderByType());
		
		return searchURL.toString();
	}
	
	/**
	 * View Item For Display Style
	 */
	@Override
	public List<ViewTypeItem> getViewTypeItems() {
		// First I Need To Create A Generic Search URL
		PortletURL portletURL = liferayPortletResponse.createRenderURL();
		
		// Need To Setup The Parameter For The URL Created 
		portletURL.setParameter("mvcRenderCommnandName", MVCCommandNames.VIEW_ASSIGNMENTS);
		
		int delta = ParamUtil.getInteger(request, SearchContainer.DEFAULT_DELTA_PARAM);
		int currentPage = ParamUtil.getInteger(request, SearchContainer.DEFAULT_CUR_PARAM);
		
		if(delta > 0) {
			portletURL.setParameter("delta", String.valueOf(delta));
		}
		if(currentPage > 0) {
			portletURL.setParameter("cur", String.valueOf(currentPage));
		}
		
		portletURL.setParameter("orderByCol", getOrderByCol());
		portletURL.setParameter("orderByType", getOrderByType());
		
		// For The Actual Process For Returning Views
		return new ViewTypeItemList(portletURL, getDisplayStyle()) {
			{
				addTableViewTypeItem();
				addListViewTypeItem();
			}
		};
	}
	
	@Override
	protected List<DropdownItem> getOrderByDropdownItems() {
		return new DropdownItemList() {
			{
				add(
					dropdownItem -> {
						dropdownItem.setActive("title".equals(getOrderByCol()));
						dropdownItem.setHref(getCurrentSortingURL(), "orderByCol", "title");
						dropdownItem.setLabel(LanguageUtil.get(request, "title"));
					}
				);
				
				add(
					dropdownItem -> {
						dropdownItem.setActive("createDate".equals(getOrderByCol()));
						dropdownItem.setHref(getCurrentSortingURL(), "orderByCol", "createDate");
						dropdownItem.setLabel(LanguageUtil.get(request, "create-date"));
					}
				);
			}
		};
	}
	
	private PortletURL getCurrentSortingURL() throws PortletException{
		PortletURL sortingURL = PortletURLUtil.clone(currentURLObj, liferayPortletResponse);
		sortingURL.setParameter("mvcRenderCommnandName", MVCCommandNames.VIEW_ASSIGNMENTS);
		
		// Reset My View From The Current Sorted View
		sortingURL.setParameter(SearchContainer.DEFAULT_CUR_PARAM, "0");
		
		String keywords = ParamUtil.getString(request, "keywords");
		
		if(Validator.isNotNull(keywords)) {
			sortingURL.setParameter("keywords", keywords);
		}
		
		return sortingURL;
	}
	
	private final PortalPreferences portalPreferences;
	private final ThemeDisplay themeDisplay;
}
