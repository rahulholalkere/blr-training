package com.liferay.training.gradebook.service.workflow;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.ResourceActions;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandler;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentLocalService;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * 
 * @author me
 * For working with workflow handler with Assignment Entity
 */
@Component(
	immediate = true,
	service = WorkflowHandler.class
)
public class AssignmentWorkflowHandler extends BaseWorkflowHandler<Assignment>{

	@Override
	public String getClassName() {
		return Assignment.class.getName();
	}

	@Override
	public String getType(Locale locale) {
		return resourceActions.getModelResource(locale, getClassName());
	}

	@Override
	public Assignment updateStatus(int status, Map<String, Serializable> workflowContext) throws PortalException {
		long userId = GetterUtil.getLong((String) workflowContext.get(WorkflowConstants.CONTEXT_USER_ID));
		long resourePrimaryKey = GetterUtil.getLong((String) workflowContext.get(WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));
		
		ServiceContext serviceContext = (ServiceContext) workflowContext.get("serviceContext");
		return assignmentLocalService.updateStatus(userId, resourePrimaryKey, status ,serviceContext);
	}
	
	@Reference
	private AssignmentLocalService assignmentLocalService;
	
	@Reference
	private ResourceActions resourceActions;
	
}
