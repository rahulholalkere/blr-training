package com.liferay.training.gradebook.internal.security.permission.resource.definition;

import com.liferay.exportimport.kernel.staging.permission.StagingPermission;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.StagedModelPermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.WorkflowedModelPermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.definition.ModelResourcePermissionDefinition;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.workflow.permission.WorkflowPermission;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentLocalService;

import java.util.function.Consumer;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * This Class Represents For Registering The Assignment Model and Top-Level Permissions
 * @author hgrahul
 *
 */
@Component(immediate = true, service = ModelResourcePermissionDefinition.class)
public class AssignmentModelResourcePermissionDefinition implements ModelResourcePermissionDefinition<Assignment>{
	/**
	 * Assignment Metadata To Be Passed To The Assignment Permission Model
	 */
	@Override
	public Assignment getModel(long assignmentId) throws PortalException {
		return assignmentLocalService.getAssignment(assignmentId);
	}
	
	@Override
	public Class<Assignment> getModelClass() {
		return Assignment.class;
	}
	
	@Override
	public long getPrimaryKey(Assignment assignment) {
		return assignment.getAssignmentId();
	}
	
	@Override
	public PortletResourcePermission getPortletResourcePermission() {
		return portletResourcePermission;
	}
	
	/**
	 * Actual Registery Model For Permission Register Purpose
	 */
	@Override
	public void registerModelResourcePermissionLogics(ModelResourcePermission<Assignment> modelResourcePermission, Consumer<ModelResourcePermissionLogic<Assignment>> modelResourcePermissionLogicConsumer) {
		modelResourcePermissionLogicConsumer.accept(
			new StagedModelPermissionLogic<>(stagingPermission, "com_liferay_training_gradebook_web_portlet_GradebookPortlet", Assignment::getAssignmentId)
		);
		
		// For Workflow Related Stages
		modelResourcePermissionLogicConsumer.accept(
			new WorkflowedModelPermissionLogic<>(workflowPermission, modelResourcePermission, groupLocalService, Assignment::getAssignmentId)
		);
	}
	
	/**
	 * For Reference Which We Will Need In This Registeration Process For Model and Top Level Permissions
	 */
	@Reference
	private AssignmentLocalService assignmentLocalService;
	
	@Reference
	private GroupLocalService groupLocalService;
	
	@Reference(target = "(resource.name=com.liferay.training.gradebook.model)")
	private PortletResourcePermission portletResourcePermission;
	
	@Reference
	private StagingPermission stagingPermission;
	
	@Reference
	private WorkflowPermission workflowPermission;
}
