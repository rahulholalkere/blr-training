package com.liferay.training.demo.constants;

/**
 * @author hgrahul
 */
public class MyPortletKeys {
	public static final String PORTLET_NAME ="com_liferay_training_demo_portlet_MyPortlet";
}