package com.liferay.training.demo.portlet;

import com.liferay.training.demo.constants.MyPortletKeys;

import java.io.IOException;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletConfig;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author hgrahul
 */
@Component(
	immediate = true,
	property = {
		// Which Category The Portlet Will Be Loaded
		"com.liferay.portlet.display-category=category.training",
		// CSS For My Portlet
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		
		// Proview Javascripting For Portlet
		"com.liferay.portlet.footer-portlet-javascript=/js/main.js",
		
		// Multiple Instance On Current Page
		"com.liferay.portlet.instanceable=false",
		
		// Display Name Of My Portlet In Category
		"javax.portlet.display-name=Rahul Portlet",
		
		// Associated Template Root Location "META-INF/resource"
		"javax.portlet.init-param.template-path=/",
		
		// Associated Template View Location
		"javax.portlet.init-param.view-template=/view.jsp",
		
		// Internal Liferay Portlet Name
		"javax.portlet.name=" + MyPortletKeys.PORTLET_NAME,
		
		// Language Property For My Portlet
		"javax.portlet.resource-bundle=content.Language",

		// Default Role Specification For My Portlet
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class MyPortlet extends MVCPortlet {
	@Override
	public void init(PortletConfig config) throws PortletException {
		System.out.println("Portlet Intialized");
		super.init(config);
	}
	
	@Override
	public void destroy() {
		System.out.println("Portlet Destroyed Or Moved For Update");
		super.destroy();
	}
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		System.out.println("Portlet Rendering Invoked");
		System.out.println("Portlet Method [" + renderRequest.getPortletMode() + "] Invoked");
		super.render(renderRequest, renderResponse);
	}
	
	@Override
	protected void doDispatch(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		System.out.println("Portlet Dispatch Invoked");
		System.out.println("Portlet Method [" + renderRequest.getPortletMode() + "] Invoked");
		super.doDispatch(renderRequest, renderResponse);
	}
	
	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		System.out.println("Portlet View Mode is In Execution");
		super.doView(renderRequest, renderResponse);
	}
	
	@Override
	public void doEdit(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		System.out.println("Portlet Edit Mode is In Execution");
		super.doEdit(renderRequest, renderResponse);
	}
	
	@Override
	public void processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws IOException, PortletException {
		System.out.println("Portlet Action Called...");
		super.processAction(actionRequest, actionResponse);
	}
	
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, PortletException {
		System.out.println("Portlet Serve Resource Phase");
		resourceResponse.setContentType("text/html");
		resourceResponse.getWriter().write("Resource Served Appropriately");
	}
}